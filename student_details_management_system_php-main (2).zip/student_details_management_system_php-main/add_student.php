<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/dbconnection.php');

if (strlen($_SESSION['sid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        // Collecting all input values
        $studentno = mysqli_real_escape_string($con, $_POST['studentno']);
        $studentName = mysqli_real_escape_string($con, $_POST['studentName']);
        $class = mysqli_real_escape_string($con, $_POST['class']);
        $dateofbirth = mysqli_real_escape_string($con, $_POST['dateofbirth']);
        $age = mysqli_real_escape_string($con, $_POST['age']);
        $gender = mysqli_real_escape_string($con, $_POST['gender']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $contactno = mysqli_real_escape_string($con, $_POST['contactno']);
        $nextphone = mysqli_real_escape_string($con, $_POST['nextphone']);
        $City = mysqli_real_escape_string($con, $_POST['City']);
        $Baranggay = mysqli_real_escape_string($con, $_POST['Baranggay']);
        $House = mysqli_real_escape_string($con, $_POST['House']);
        $Street = mysqli_real_escape_string($con, $_POST['Street']);
        $studentImage = $_FILES['studentImage'];
        $parentName = mysqli_real_escape_string($con, $_POST['parentName']);
        $relation = mysqli_real_escape_string($con, $_POST['relation']);
        $occupation = mysqli_real_escape_string($con, $_POST['occupation']);
        $generated_code = mysqli_real_escape_string($con, $_POST['generated_code']);
        $passcode = mysqli_real_escape_string($con, $_POST['passcode']); // Get the passcode

        // Handle image upload
        if ($studentImage['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'studentimages/';
            $uploadFile = $uploadDir . basename($studentImage['name']);

            if (move_uploaded_file($studentImage['tmp_name'], $uploadFile)) {
                $studentImagePath = $studentImage['name']; // Store only the file name in the database
            } else {
                echo "<script>alert('Failed to upload image.');</script>";
                exit;
            }
        } else {
            echo "<script>alert('Error uploading file.');</script>";
            exit;
        }

        // Check if student number already exists
        $query = "SELECT * FROM students WHERE studentno = '$studentno'";
        $result = mysqli_query($con, $query);
        if (mysqli_num_rows($result) > 0) {
            echo "<script>alert('Student number already exists. Please enter a unique student number.'); window.location.href = 'add_student.php';</script>";
            exit;
        }

        // Insert data into the database including passcode
        $query = mysqli_query($con, "INSERT INTO students (studentno, studentName, class, dateofbirth, age, gender, email, parentName, relation, occupation, City, Baranggay, Street, House, studentImage, contactno, nextphone, generated_code, passcode)
            VALUES ('$studentno', '$studentName', '$class', '$dateofbirth', '$age', '$gender', '$email', '$parentName', '$relation', '$occupation', '$City', '$Baranggay', '$Street', '$House' , '$studentImagePath', '$contactno', '$nextphone', '$generated_code', '$passcode')");

        // Check if query was successful
        if ($query) {
            echo "<script>alert('Student has been registered.');</script>";
            echo "<script>window.location.href = 'add_student.php';</script>";
        } else {
            echo "<script>alert('Something Went Wrong. Please try again.');</script>";
        }
    }
}
?>
  <!DOCTYPE html>
  <html>
  <?php @include("includes/head.php"); ?>
  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Navbar -->
      <?php @include("includes/header.php"); ?>
      <!-- /.navbar -->

      <!-- Main Sidebar Container -->
      <?php @include("includes/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Add Student</li>
                </ol>
              </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row ">
              <div class="col-md-12">
                <!-- general form elements -->`
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">Add Student</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="add_student.php" enctype="multipart/form-data">
                    <div class="card-body">
                      <span style="color: brown"><h5>Student details</h5></span>
                      <hr>
                      <div class="row">
                        <div class="form-group col-md-3">
                          <label for="studentno">Student No.</label>
                          <input type="text" class="form-control" id="studentno" name="studentno" placeholder="Enter student No" required>
                        </div>
                        <div class="form-group col-md-5">
                          <label for="names">Names</label>
                          <input type="text" class="form-control" id="studentName" name="studentName" placeholder="Names" required>
                        </div>
                        <div class="form-group col-md-2">
                          <label for="age">Age</label>
                          <input type="text" class="form-control" id="age" name="age" placeholder="age"required>
                        </div>
                        <div class="form-group col-md-2">
                          <label for="gender">Sex</label>
                          <select type="select" class="form-control" id="gender" name="gender"required>
                            <option>Select Sex</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                          </select>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group col-md-4">
                          <label for="class">Year Level</label>
                          <select type="select" class="form-control" id="class" name="class" required>
                            <option>Select Year Level</option>
                            <option value="Grade 7">Grade 7</option>
                            <option value="Grade 8">Grade 8</option>
                            <option value="Grade 9">Grade 9</option>
                            <option value="Grade 10">Grade 10</option>
                            <option value="Grade 11">Grade 11</option>
                            <option value="Grade 12">Grade 12</option>
                          </select>
                        </div>
                        <div class="form-group col-md-4">
                          <label for="age">Birthdate<span style="color: blue;">*required</span></label><br>
                            <input type="date" id="dateofbirth" name="dateofbirth">
                        </div>

                        <div class="form-group col-md-4">
                          <label for="exampleInputFile">Student Photo</label>
                          <div class="input-group">
                            <div class="custom-file">
                              <input type="file" class="" name="studentImage" id="photo" required>
                            </div>
                          </div>
                        </div>

                      </div>
                      <hr>
                      <span style="color: brown"><h5>Parent details</h5></span>
                      <div class="row">
                        <div class="form-group col-md-3">
                          <label for="parentName">Parent Name.</label>
                          <input type="text" class="form-control" id="parentName" name="parentName" placeholder="Enter Name" required>
                        </div>
                        <div class="form-group col-md-5">
                          <label for="relation">Relationship</label>
                          <select type="select" class="form-control" id="relation" name="relation"required>
                            <option>Select Relationship</option>
                            <option value="Father">Father</option>
                            <option value="Mother">Mother</option>
                            <option value="Uncle">Uncle</option>
                            <option value="Aunt">Aunt</option>
                            <option value="Grandmother">Grandmother</option>
                            <option value="Grandfather">Grandfather</option>
                          </select>
                        </div>
                        <div class="form-group col-md-2">
                          <label for="age">Email</label>
                          <input type="text" class="form-control" id="email" name="email" placeholder="email" required>
                        </div>
                        <div class="form-group col-md-2">
                          <label for="occupation">Occupation</label>
                          <input type="text" class="form-control" id="occupation" name="occupation" placeholder="Teacher"required>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group col-md-3 offset-md-6">
                          <label for="phone1">Phone 1</label>
                          <input type="tel" class="form-control" id="contactno" name="contactno" placeholder="09876543210" maxlength="11"required>
                        </div>
                        <div class="form-group col-md-3">
                          <label for="nextphone">Phone 2</label>
                          <input type="tel" class="form-control" id="nextphone" name="nextphone" placeholder="09876543210" maxlength="11" required>
                        </div>
                      </div>
                      <hr>
                      <span style="color: brown"><h5>Address</h5></span>
                      <div class="row">
                        <div class="form-group col-md-3 ">
                          <label for="City">City/Municipality</label>
                          <input type="text" class="form-control" id="City" name="City" placeholder="City/Municipality"required>
                        </div>
                        <div class="form-group col-md-3 ">
                          <label for="Baranggay">Baranggay</label>
                          <input type="text" class="form-control" id="Baranggay" name="Baranggay" placeholder="Baranggay"required>
                        </div>
                        <div class="form-group col-md-3 ">
                          <label for="Street">Street Name</label>
                          <input type="text" class="form-control" id="Street" name="Street" placeholder="Street Name"required>
                        </div>
                        <div class="form-group col-md-3">
                          <label for="House">House Number</label>
                          <input type="text" class="form-control" id="House" name="House" placeholder="House Number"required>
                        </div>
                      </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                          <button type="button" class="btn btn-secondary form-control qr-generator" id="generate-qr-btn" onclick="generateQrCode()" style="width:200px;" disabled>Generate QR Code</button>
                          <div class="qr-con text-center" style="display: none;">
                          <input type="hidden" class="form-control" id="generated_code" name="generated_code">
                          <p>Take a pic with your qr code.</p>
                          <img class="mb-4" src="" id="qrImg" alt="">
                          
                      <div class="form-group">
                        <label for="passcode">Enter Passcode</label>
                        <input type="text" class="form-control" id="passcode" name="passcode" placeholder="Enter Passcode" maxlength="6" required>
                      </div>
                      <button type="submit" class="btn btn-dark" id="submit-btn" name="submit">Submit</button>

                      </div>

                  </form>

                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <?php @include("includes/footer.php"); ?>

    </div>

    <!-- ./wrapper -->
    <?php @include("includes/foot.php"); ?>
<script>
  function generateQrCode() {
    const qrImg = document.getElementById('qrImg');
    const generatedCodeInput = document.getElementById('generated_code');
    const passcodeInput = document.getElementById('passcode');

    // Generate a random code
    const randomCode = generateRandomCode(10);
    generatedCodeInput.value = randomCode;

    // Use the random code and passcode to generate the QR code
    const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(randomCode + '|' + passcodeInput.value)}`;
    qrImg.src = apiUrl;

    // Show the QR code and submit button
    document.querySelector('.qr-con').style.display = '';
    document.querySelector('.qr-generator').style.display = 'none';
    document.getElementById('submit-btn').style.display = 'block';
  }

  function generateRandomCode(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let randomString = '';

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      randomString += characters.charAt(randomIndex);
    }

    return randomString;
  }

  function checkRequiredFields() {
    const requiredFields = [
      'studentno', 'studentName', 'age', 'gender', 'class', 'dateofbirth',
      'parentName', 'relation', 'email', 'occupation', 'contactno',
      'nextphone', 'City', 'Baranggay', 'Street', 'House'
    ];

    const generateQrBtn = document.getElementById('generate-qr-btn');
    // Check if all required fields are filled
    const allFilled = requiredFields.every(fieldId => {
      const field = document.getElementById(fieldId);
      return field && field.value.trim() !== '';
    });

    generateQrBtn.disabled = !allFilled; // Enable/disable the button based on the check
  }

  // Add event listeners to required fields to check if they are filled
  const requiredFields = [
    'studentno', 'studentName', 'age', 'gender', 'class', 'dateofbirth',
    'parentName', 'relation', 'email', 'occupation', 'contactno',
    'nextphone', 'City', 'Baranggay', 'Street', 'House'
  ];

  requiredFields.forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (field) {
      field.addEventListener('input', checkRequiredFields);
    }
  });

  // Initial check in case fields are pre-filled
  checkRequiredFields();
</script>
  </body>
  </html>
  <?php
?>
