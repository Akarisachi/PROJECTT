<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sid']==0)) {
header('location:logout.php');
} 
?>
<!DOCTYPE html>
<html>
<?php @include("includes/head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php @include("includes/header.php"); ?>
        <!-- Main Sidebar Container -->
        <?php @include("includes/sidebar.php"); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Dashboard</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <section class="content">
    <div class="container-fluid">
        <!-- Row for Grades 7-10 -->
        <h1 class="m-0 text-dark">Junior High School Department</h1><br>
        <div class="row">
            <div class="col-lg-4 col-6">
                <div class="small-box bg-success">
                    <?php 
                    $query2 = mysqli_query($con, "SELECT * FROM students WHERE class='Grade 7'");
                    $totalGrade7 = mysqli_num_rows($query2);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade7; ?></h3>
                        <p>Total Grade 7 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-6">
                <div class="small-box bg-info">
                    <?php 
                    $query3 = mysqli_query($con, "SELECT * FROM students WHERE class='Grade 8'");
                    $totalGrade8 = mysqli_num_rows($query3);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade8; ?></h3>
                        <p>Total Grade 8 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-6">
                <div class="small-box bg-success">
                    <?php 
                    $query2 = mysqli_query($con, "SELECT * FROM students WHERE class='Grade 9'");
                    $totalGrade9 = mysqli_num_rows($query2);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade9; ?></h3>
                        <p>Total Grade 9 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-6">
                <div class="small-box bg-info">
                    <?php 
                    $query3 = mysqli_query($con, "SELECT * FROM students WHERE class='Grade 10'");
                    $totalGrade10 = mysqli_num_rows($query3);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade10; ?></h3>
                        <p>Total Grade 10 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <hr>

        <!-- Row for Grades 11-12 -->
        <h1 class="m-0 text-dark">Senior High School Department</h1><br>
        <div class="row">
            <div class="col-lg-4 col-6">
                <div class="small-box bg-success">
                    <?php 
                    $query2 = mysqli_query($con, "SELECT * FROM students WHERE class='Grade 11'");
                    $totalGrade11 = mysqli_num_rows($query2);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade11; ?></h3>
                        <p>Total Grade 11 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-6">
                <div class="small-box bg-info">
                    <?php 
                    $query3 = mysqli_query($con, " SELECT * FROM students WHERE class='Grade 12'");
                    $totalGrade12 = mysqli_num_rows($query3);
                    ?>
                    <div class="inner">
                        <h3><?php echo $totalGrade12; ?></h3>
                        <p>Total Grade 12 students</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                    <a href="student_list.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
    </div>
    <!-- /.content-wrapper -->
    <?php @include("includes/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php @include("includes/foot.php"); ?>
</body>
</html>
