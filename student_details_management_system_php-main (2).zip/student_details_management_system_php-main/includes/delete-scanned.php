<?php
include("dbconnection.php");

header('Content-Type: application/json');

// Fetch the table structure
try {
    $stmt = $dbh->prepare("DESCRIBE tbl_scanned");
    $stmt->execute();
    $tableStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Find the primary key column
    $primaryKeyColumn = null;
    foreach ($tableStructure as $column) {
        if ($column['Key'] == 'PRI') {
            $primaryKeyColumn = $column['Field'];
            break;
        }
    }

    if (!$primaryKeyColumn) {
        echo json_encode(['success' => false, 'error' => 'Primary key not found in tbl_scanned']);
        exit;
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    try {
        // Check if the record exists
        $checkStmt = $dbh->prepare("SELECT $primaryKeyColumn FROM tbl_scanned WHERE $primaryKeyColumn = :id");
        $checkStmt->bindParam(':id', $id, PDO::PARAM_INT);
        $checkStmt->execute();
        
        if ($checkStmt->rowCount() > 0) {
            // Record exists, proceed with deletion
            $deleteStmt = $dbh->prepare("DELETE FROM tbl_scanned WHERE $primaryKeyColumn = :id");
            $deleteStmt->bindParam(':id', $id, PDO::PARAM_INT);
            $deleteStmt->execute();
            
            if ($deleteStmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Record deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to delete record']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => "Record not found. ID: $id, PrimaryKey: $primaryKeyColumn"]);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No ID provided']);
}
?>