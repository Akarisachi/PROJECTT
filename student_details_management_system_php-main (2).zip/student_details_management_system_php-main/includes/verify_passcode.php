<?php
include("dbconnection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['qr_code']) && isset($_POST['passcode'])) {
        $qrCode = $_POST['qr_code'];
        $passcode = $_POST['passcode'];

        // Split the QR code to get the generated code
        $qrParts = explode('|', $qrCode);
        $generatedCode = $qrParts[0];

        $stmt = $dbh->prepare("SELECT passcode FROM students WHERE generated_code = :generated_code");
        $stmt->bindParam(':generated_code', $generatedCode, PDO::PARAM_STR);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result && $result['passcode'] === $passcode) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing parameters']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}