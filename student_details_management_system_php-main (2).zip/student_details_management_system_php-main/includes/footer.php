<footer class="main-footer">
  <strong>If you encounter any problems, please contact me through email.&copy; <script>document.write(new Date().getFullYear());</script> <a href="mailto:catapangken55@gmail.com">Click this to email me</a>.</strong>
</footer>