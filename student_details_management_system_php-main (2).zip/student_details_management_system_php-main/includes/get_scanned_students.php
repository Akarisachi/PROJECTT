<?php
include("dbconnection.php");

try {
    $stmt = $dbh->prepare("SELECT s.id, s.studentno, s.studentName, s.class, ts.time_scanned 
                           FROM tbl_scanned ts
                           JOIN students s ON ts.studentno = s.studentno
                           ORDER BY ts.time_scanned DESC");
    $stmt->execute();

    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($students);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>