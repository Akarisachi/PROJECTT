<?php
include("../includes/dbconnection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['qr_code'])) {
        $qrCode = $_POST['qr_code'];

        // Split the QR code to get the generated code
        $qrParts = explode('|', $qrCode);
        $generatedCode = $qrParts[0];

        try {
            $stmt = $dbh->prepare("SELECT * FROM students WHERE generated_code = :generated_code");
            $stmt->bindParam(':generated_code', $generatedCode, PDO::PARAM_STR);
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                // Add the student to the scanned list
                $stmt = $dbh->prepare("INSERT INTO tbl_scanned (studentno) VALUES (:studentno)");
                $stmt->bindParam(':studentno', $result['studentno'], PDO::PARAM_STR);
                $stmt->execute();

                $scannedId = $dbh->lastInsertId();

                // Prepare the response data
                $responseData = [
                    'success' => true,
                    'student' => [
                        'id' => $scannedId,
                        'studentno' => $result['studentno'],
                        'studentName' => $result['studentName'],
                        'class' => $result['class'],
                        'time_scanned' => date('Y-m-d H:i:s')
                    ]
                ];

                echo json_encode($responseData);
            } else {
                echo json_encode(['success' => false, 'error' => 'Student not found']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing parameters']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>